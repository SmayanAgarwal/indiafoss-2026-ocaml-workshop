# hello-mirage

A minimal MirageOS unikernel that logs `hello` four times, once per
second, and exits. The companion artifact for
[M12-L03 "MirageOS Basics"](https://fplaunchpad.github.io/ocaml_nptel/M12-L03-mirageos.html)
in the NPTEL course *Functional Programming with OCaml*.

The source is two files:

```
config.ml      the manifest: declares the unikernel and its packages
unikernel.ml   the unikernel body (the loop that logs and sleeps)
```

Everything else (the `Makefile`, the dune files, the `mirage/`
directory with the generated `main.ml`) is produced by
`mirage configure` and regenerated on every reconfigure.

## Prerequisites

You need OCaml >= 4.14 and the `mirage` command-line tool
(this skeleton targets mirage >= 4.9 and < 4.12):

```sh
opam switch create 5.4.0
opam install mirage
```

For the KVM/Solo5 target you additionally need `solo5`
(Linux only):

```sh
opam install solo5
```

KVM itself only matters at runtime, not build time.

## Build and run: Unix backend

The Unix backend turns the unikernel into a regular process.
Easiest path; no virtualisation required; works on macOS too.

```sh
mirage configure -t unix
make depend      # vendors the packages config.ml asked for
make             # produces an executable `./dist/hello`
./dist/hello
```

Expected output, four lines, one per second:

```
2026-06-12T13:01:23+05:30: [INFO] [application] hello
```

## Build and run: Solo5 / KVM backend

The Solo5 backend turns the same source into a unikernel image you
boot on a hypervisor.

```sh
mirage configure -t hvt
make depend
make             # produces `dist/hello.hvt`, a Solo5 image
solo5-hvt -- dist/hello.hvt
```

## Clean up

```sh
mirage clean     # removes generated files; source files survive
```

## Going further

Replace `unikernel.ml` with something more interesting. Look at
mirage-skeleton (https://github.com/mirage/mirage-skeleton)
for a dozen tutorial unikernels covering networking, storage, and
TLS; its `tutorial/` directory is the good next read.

## Provenance

The `config.ml` and `unikernel.ml` here follow the shape of
mirage-skeleton's `tutorial/hello` example
(https://github.com/mirage/mirage-skeleton, under that
repository's licence). Used here as a teaching artefact for the
NPTEL course.
